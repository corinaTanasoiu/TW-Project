//navbar
import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import logo from './Assets/logo2.jpg';
import user from './Assets/user.png';
import logout from './Assets/logout.png';
import profile from './Assets/profile.png';
import settings from './Assets/setting.png';
import help from './Assets/help.png';

const Navbar = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [isOpen, setIsOpen] = useState(false);

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  const handleLogout = () => {
    localStorage.removeItem('isLoggedIn'); // Șterge valoarea de autentificare
    navigate('/'); // Redirecționează utilizatorul la pagina de login
  };

  const handleHomeClick = (e) => {
    e.preventDefault(); // Previne navigarea implicită
    if (location.pathname !== "/dashboard") {
      navigate('/dashboard'); // Navighează doar dacă nu suntem deja pe dashboard
    }
  };
  

  return (
    <nav>
      <img src={logo} alt="Logo" />
      <ul>
      <li><a href="/dashboard" onClick={handleHomeClick}>Home</a></li>
        <li><a href="/features">Features</a></li>
        <li><a href="/about">About</a></li>
      </ul>
      <img
        src={user}
        className="user-pic"
        onClick={toggleMenu}
        alt="User"
      />
      <div className={`sub-menu-wrap ${isOpen ? 'open-menu' : ''}`}>
        <div className="sub-menu">
          <div className="user-info">
            <img src={user} alt="User" />
            <h2>{localStorage.getItem('email') || 'User'}</h2>
          </div>
          <hr />
          <a href="#" className='sub-menu-link'>
            <img src={profile} alt="Profile" />
            <p>Edit Profile</p>
            <span>›</span>
          </a>
          <a href="#" className='sub-menu-link'>
            <img src={settings} alt="Settings" />
            <p>Settings</p>
            <span>›</span>
          </a>
          <a href="#" className='sub-menu-link'>
            <img src={help} alt="Help" />
            <p>Help</p>
            <span>›</span>
          </a>
          <a
            href="#"
            className='sub-menu-link'
            onClick={(e) => {
              e.preventDefault();
              handleLogout();
            }}
          >
            <img src={logout} alt="Logout" />
            <p>Log Out</p>
            <span>›</span>
          </a>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;

