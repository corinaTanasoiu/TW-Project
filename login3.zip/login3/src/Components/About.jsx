import React from 'react';
import './About.css';

const About = () => {
  return (
    <div className="about-container">
      <h1>Despre BugCatcher</h1>
      <p>
        <strong>BugCatcher</strong> este o aplicație web inovativă creată pentru gestionarea și monitorizarea bug-urilor într-un proiect software. Aplicația facilitează o comunicare rapidă și eficientă între membrii echipei, ajutând astfel la rezolvarea problemelor întâmpinate în timpul dezvoltării unui proiect software. 
        BugCatcher permite urmărirea completă a bug-urilor, de la înregistrarea acestora până la soluționarea finală, și oferă un sistem de permisiuni care definește ce pot face membrii echipei în cadrul aplicației. Aplicația este construită astfel încât să sprijine atât dezvoltatori, cât și testeri, permițându-le să colaboreze într-un mod organizat și transparent.
      </p>

      <h2>Funcționalități principale:</h2>
      <ul>
        <li><strong>Autentificare pe bază de email:</strong> Utilizatorii se pot conecta în aplicație printr-un cont bazat pe adresa de email, asigurându-se că doar persoanele autorizate au acces la informațiile și proiectele din aplicație.</li>
        <li><strong>Adăugarea și gestionarea proiectelor software:</strong> Membrii echipei pot crea și administra proiecte software, specificând detalii precum repository-ul proiectului și echipa de dezvoltare. Aceasta asigură o vizibilitate completă asupra proiectelor care sunt monitorizate în aplicație.</li>
        <li><strong>Înregistrarea și urmărirea bug-urilor:</strong> Testatorii (TST) pot înregistra bug-uri, specificând informații precum severitatea, descrierea și linkul către commit-ul care a generat bug-ul. De asemenea, se pot urmări progresul rezolvării acestora.</li>
        <li><strong>Alocarea și rezolvarea bug-urilor:</strong> Membrii echipei de management (MP) pot aloca bug-uri altor membri ai echipei, iar după rezolvare, pot actualiza statusul bug-ului cu un link către commit-ul în care bug-ul a fost remediat.</li>
        <li><strong>Sistem de permisiuni:</strong> Aplicația utilizează un sistem de permisiuni pentru a diferentia între rolurile de MP (membri ai echipei de management) și TST (testeri). MP pot adăuga, modifica proiecte și actualiza statusul unui bug, în timp ce TST pot doar să adauge bug-uri.</li>
      </ul>

      <h2>Echipa de dezvoltare:</h2>
      
      <ul>
        <li><strong>Tocu Alexandru</strong></li>
        <li><strong>Zarnescu Cristina</strong></li>
        <li><strong>Tanasoiu Corina</strong></li>
        <li><strong>Tertes Raluca</strong></li>
      </ul>


      <h2>Inspirat de platforme precum <a href="https://www.bugzilla.org/" target="_blank" rel="noopener noreferrer">Bugzilla</a></h2>
      <p>
        BugCatcher se inspiră din platforme consacrate de urmărire a bug-urilor, precum <strong>Bugzilla</strong>, iar scopul său este de a aduce o soluție similară pentru echipele care dezvoltă software în cadrul proiectelor lor.
      </p>
    </div>
  );
};

export default About;
