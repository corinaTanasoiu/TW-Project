import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import './Dashboard.css';
import logo from './Assets/logo2.jpg';
import user from './Assets/user.png';
import logout from './Assets/logout.png';
import profile from './Assets/profile.png';
import settings from './Assets/setting.png';
import help from './Assets/help.png';
import { Link } from 'react-router-dom';


const Dashboard = () => {
  const navigate = useNavigate();
  const [isOpen, setIsOpen] = useState(false);
  const [projects, setProjects] = useState([]);

  // Fetch projects when component mounts
  useEffect(() => {
    fetchProjects();
  }, []);

  const fetchProjects = async () => {
    try {
      const response = await axios.get('http://localhost:8080/api/projects/all');
      console.log('Projects fetched:', response.data);
      setProjects(response.data);
    } catch (error) {
      console.error('Error fetching projects:', error);
    }
  };

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('email');
    navigate('/');
  };

  const handleAddProject = () => {
    navigate('/project-form');
  };

  return (
    <div className="dashboard-container">
      <nav>
        <img src={logo} alt="Logo" />
        <ul>
          <li><Link to="/home">Home</Link></li>
          <li><Link to="/features">Features</Link></li>
          <li><Link to="/about">About</Link></li>
        </ul>
        <img
          src={user}
          className="user-pic"
          onClick={toggleMenu}
          alt="User"
        />
        <div className={`sub-menu-wrap ${isOpen ? 'open-menu' : ''}`}>
          <div className="sub-menu">
            <div className="user-info">
              <img src={user} alt="User" />
              <h2>{localStorage.getItem('email') || 'User'}</h2>
            </div>
            <hr />
            <a href="#" className='sub-menu-link'>
              <img src={profile} alt="Profile" />
              <p>Edit Profile</p>
              <span>›</span>
            </a>
            <a href="#" className='sub-menu-link'>
              <img src={settings} alt="Settings" />
              <p>Settings</p>
              <span>›</span>
            </a>
            <a href="#" className='sub-menu-link'>
              <img src={help} alt="Help" />
              <p>Help</p>
              <span>›</span>
            </a>
            <a
              href="#"
              className='sub-menu-link'
              onClick={(e) => {
                e.preventDefault();
                handleLogout();
              }}
            >
              <img src={logout} alt="Logout" />
              <p>Log Out</p>
              <span>›</span>
            </a>
          </div>
        </div>
      </nav>

      <div className="projects-section">
        <h2>Current Projects</h2>
        <div className="projects-container">
          {projects.map((project, index) => (
            <div key={project.projectNo || index} className="project-card">
              <h3>{project.name}</h3>
              <p>{project.description}</p>
              <p>Application: {project.app}</p>
              <button>View</button>
            </div>
          ))}
        </div>
        <button className="add-project-btn" onClick={handleAddProject}>
          Add a new project
        </button>
      </div>
    </div>
  );
};

export default Dashboard;