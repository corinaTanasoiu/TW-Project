// src/Components/Features.jsx
import React from 'react';
import './Features.css';

const Features = () => {
  return (
    <div className="features-container">
      <h1>Features - BugCatcher</h1>
      <p>
        BugCatcher este o aplicație web dedicată gestionării bug-urilor într-un proiect software. 
        Aceasta facilitează comunicarea între membrii echipei pentru o rezolvare rapidă și eficientă a problemelor.
      </p>
      
      <h2>Funcționalități principale:</h2>
      <ul>
        <li>
          <strong>Autentificare</strong>: Ca student, mă pot conecta la aplicație folosind un cont bazat pe o adresă de email.
        </li>
        <li>
          <strong>Înregistrarea unui proiect</strong>: Ca student membru într-o echipă de proiect (MP), pot să înregistrez un proiect software pentru a fi monitorizat, specificând repository-ul proiectului și echipa de proiect.
        </li>
        <li>
          <strong>Adăugarea ca tester</strong>: Ca student care nu face parte dintr-un proiect înregistrat, pot să mă adaug ca tester (TST) la un proiect existent.
        </li>
        <li>
          <strong>Înregistrarea unui bug</strong>: Ca tester (TST), pot să înregistrez un bug, incluzând severitatea, prioritatea de rezolvare, descrierea și un link către commit-ul la care se referă.
        </li>
        <li>
          <strong>Vizualizarea bug-urilor</strong>: Ca MP, pot vizualiza bug-urile înregistrate pentru proiectele în care sunt implicat.
        </li>
        <li>
          <strong>Alocarea unui bug</strong>: Ca MP, pot aloca rezolvarea unui bug. Un singur MP poate fi alocat unui bug la un moment dat.
        </li>
        <li>
          <strong>Rezolvarea unui bug</strong>: Ca MP, după ce am rezolvat un bug, pot adăuga un status de rezolvare cu un link către commit-ul în care am rezolvat bug-ul.
        </li>
        <li>
          <strong>Sistem de permisiuni</strong>: Aplicația include un sistem de permisiuni. Un MP poate adăuga și modifica proiecte și poate actualiza statusul unui bug. Un TST poate doar să adauge bug-uri.
        </li>
      </ul>

      <p>
        Exemplu: <a href="https://www.bugzilla.org/" target="_blank" rel="noopener noreferrer">Bugzilla</a>.
      </p>
    </div>
  );
};

export default Features;
