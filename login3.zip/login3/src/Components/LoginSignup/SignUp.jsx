import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './LoginSignup.css';
import user_icon from '../Assets/person.png';
import email_icon from '../Assets/email.png';
import password_icon from '../Assets/password.png';import { format } from 'date-fns';

// const formattedDate = format(new Date(), 'dd-MM-yyyy HH:mm:ss');


const SignUp = () => {
  const navigate = useNavigate(); // Hook pentru navigare

  // Stări pentru câmpurile formularului
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [repeatPassword, setRepeatPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  // Handler pentru trimiterea formularului
  const handleSubmit = async (e) => {
    e.preventDefault();

    // Verifică dacă parolele coincid
    if (password !== repeatPassword) {
      setErrorMessage('Passwords do not match!');
      return;
    }

    // Creează obiectul de date pentru utilizator conform structurii UserEntity
    const user = {
      username: name,
      email: email,
      password: password,
      role: 'STUD', // Setează un rol implicit
      // dateCreated: formattedDate, // Data curentă
    };
    console.log('User data:', user);


    // Trimite cererea POST către serverul backend
    try {
      const response = await fetch('http://localhost:8080/api/users/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(user), // Trimite datele ca JSON
      });

      if (response.ok) {
        // Răspunsul a fost cu succes
        console.log('User registered successfully');
        setErrorMessage('');
        navigate('/'); // Navighează către pagina de login
      } else {
        // Dacă cererea eșuează
        const errorData = await response.json();
        setErrorMessage(errorData.message || 'An error occurred during registration');
      }
    } catch (error) {
      console.error('Error during registration:', error);
      setErrorMessage('An error occurred during registration');
    }
  };

  return (
    <div className="container">
      <form onSubmit={handleSubmit}>
        <h1>Sign Up</h1>
        <div className="input-box">
          <img className="icon" src={user_icon} alt="icon" />
          <input
            type="text"
            placeholder="Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>
        <div className="input-box">
          <img className="icon" src={email_icon} alt="icon" />
          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <div className="input-box">
          <img className="icon" src={password_icon} alt="icon" />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        <div className="input-box">
          <img className="icon" src={password_icon} alt="icon" />
          <input
            type="password"
            placeholder="Repeat Password"
            value={repeatPassword}
            onChange={(e) => setRepeatPassword(e.target.value)}
            required
          />
        </div>

        {/* Afișarea mesajului de eroare */}
        {errorMessage && <p className="error-message">{errorMessage}</p>}

        <button type="submit">Sign Up</button>
        <p>
          Already have an account?{' '}
          <a
            href="#"
            onClick={(e) => {
              e.preventDefault();
              navigate('/'); // Navighează către pagina de login
            }}
          >
            Login
          </a>
        </p>
      </form>
    </div>
  );
};

export default SignUp;
