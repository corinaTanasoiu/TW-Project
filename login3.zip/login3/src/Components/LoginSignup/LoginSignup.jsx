import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './LoginSignup.css';
import email_icon from '../Assets/email.png';
import password_icon from '../Assets/password.png';

const LoginSignup = ({ onLogin }) => {
  const navigate = useNavigate();
  const [errorMessage, setErrorMessage] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    const usernameOrEmail = e.target[0].value;
    const password = e.target[1].value;
    
    const credentials = {
      email: usernameOrEmail,
      password: password,
    };

    try {
      const response = await fetch('http://localhost:8080/api/users/auth', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(credentials),
      });

      if (response.ok) {
        // First try to parse as JSON
        let data;
        const contentType = response.headers.get("content-type");
        if (contentType && contentType.includes("application/json")) {
          data = await response.json();
          // If the token is in a specific field of the JSON response
          const token = data.token || data.accessToken || data;
          handleSuccessfulLogin(token, usernameOrEmail);
        } else {
          // If it's text response
          const textResponse = await response.text();
          console.log('Raw response:', textResponse);
          
          // Try different patterns to extract token
          let token = null;
          // Try to match "Token: value" pattern
          const tokenMatch = textResponse.match(/Token:\s*([^\s]+)/);
          if (tokenMatch) {
            token = tokenMatch[1];
          } else if (textResponse.includes('Bearer')) {
            // Try to match "Bearer value" pattern
            const bearerMatch = textResponse.match(/Bearer\s+([^\s]+)/);
            token = bearerMatch ? bearerMatch[1] : null;
          } else {
            // If the response is just the token itself
            token = textResponse.trim();
          }

          if (token) {
            handleSuccessfulLogin(token, usernameOrEmail);
          } else {
            setErrorMessage('Authentication successful but no token found in response');
          }
        }
      } else {
        handleError(response.status);
      }
    } catch (error) {
      console.error('Error during login:', error);
      setErrorMessage('An error occurred. Please try again later.');
    }
  };

  const handleSuccessfulLogin = (token, email) => {
    // Store token
    localStorage.setItem('token', token);
    localStorage.setItem('email', email);
    
    // Set authorization header for future requests
    // You might want to set this in your API client or axios instance
    window.fetch = new Proxy(window.fetch, {
      apply: function(fetch, that, args) {
        const [resource, config] = args;
        if (config && !config.headers?.Authorization) {
          config.headers = {
            ...config.headers,
            'Authorization': `Bearer ${token}`
          };
        }
        return fetch.apply(that, args);
      }
    });

    // Call login callback and navigate
    onLogin();
    navigate('/dashboard');
  };

  const handleError = (status) => {
    switch (status) {
      case 401:
        setErrorMessage('Invalid credentials! Please try again.');
        break;
      case 403:
        setErrorMessage('Account is locked. Please contact support.');
        break;
      default:
        setErrorMessage('An error occurred. Please try again later.');
    }
  };

  return (
    <div className="container">
      <form onSubmit={handleSubmit}>
        <h1>Login</h1>
        <div className="input-box">
          <img className="icon" src={email_icon} alt="icon" />
          <input type="text" placeholder="Email" required />
        </div>
        <div className="input-box">
          <img className="icon" src={password_icon} alt="icon" />
          <input type="password" placeholder="Password" required />
        </div>
        <div className="remember-forgot">
          <label>
            <input type="checkbox" />
            Remember me
          </label>
          <a href="#">Forgot Password?</a>
        </div>
        <button type="submit">Login</button>
        {errorMessage && <div className="error-popup">{errorMessage}</div>}
        <div className="register-link">
          <p>
            Don't have an account?{' '}
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault();
                navigate('/signup');
              }}
            >
              Sign Up
            </a>
          </p>
        </div>
      </form>
    </div>
  );
};

export default LoginSignup;