import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './ProjectForm.css';

import { useNavigate } from 'react-router-dom';

const ProjectForm = () => {
  const navigate = useNavigate();
  const [users, setUsers] = useState([]);
  const [projectData, setProjectData] = useState({
    name: '',
    description: '',
    projectNo: '',
    app: 'FRONTEND',
    members: [],
    testers: [] // Added new array for testers
  });

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await axios.get('http://localhost:8080/api/users/all');
        console.log('API Response:', response.data);
        setUsers(response.data);
      } catch (error) {
        console.error('Error fetching users:', error.response?.data || error.message);
        console.error('Full error:', error);
      }
    };
    fetchUsers();
  }, []);

  useEffect(() => {
    console.log('Current users state:', users);
  }, [users]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setProjectData(prevData => ({
      ...prevData,
      [name]: value
    }));
  };

  const handleMemberChange = (email) => {
    setProjectData(prevData => ({
      ...prevData,
      members: prevData.members.includes(email)
        ? prevData.members.filter(member => member !== email)
        : [...prevData.members, email]
    }));
  };

  const handleTesterChange = (email) => {
    setProjectData(prevData => ({
      ...prevData,
      testers: prevData.testers.includes(email)
        ? prevData.testers.filter(tester => tester !== email)
        : [...prevData.testers, email]
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Check if members are selected
    if (projectData.members.length === 0) {
      alert('Please select at least one team member');
      return;
    }

    // Format the data according to the required structure
    const formattedData = {
      name: projectData.name,
      description: projectData.description,
      projectNo: projectData.name.toLowerCase().replace(/\s+/g, '') + Date.now().toString().slice(-4), // Generate a projectNo
      app: projectData.app,
      members: [
        projectData.members.join(', ') // Join members with comma and space
      ]
    };

    console.log('Form data before sending:', formattedData);
    
    try {
      console.log('Sending project data:', formattedData);
      const response = await axios.post('http://localhost:8080/api/projects/register', formattedData, {
        headers: {
          'Content-Type': 'application/json',
        },
      });
      console.log('Project added successfully:', response.data);
      // Navigate back to dashboard after successful creation
      navigate('/dashboard');
    } catch (error) {
      console.error('Error adding project:', error.response ? error.response.data : error.message);
      alert('Failed to add project. ' + (error.response?.data || error.message));
    }
  };

  return (
    <div className="project-form-container">
      <form onSubmit={handleSubmit} className="project-form">
        <h2>Add a New Project</h2>
        
        <div className="form-group">
          <label>Project Name</label>
          <input
            type="text"
            name="name"
            value={projectData.name}
            onChange={handleChange}
            required
            className="form-control"
          />
        </div>

        <div className="form-group">
          <label>Description:</label>
          <textarea
            name="description"
            value={projectData.description}
            onChange={handleChange}
            required
            className="form-control"
          ></textarea>
        </div>

        <div className="form-group">
          <label>Application:</label>
          <select 
            name="app" 
            value={projectData.app} 
            onChange={handleChange}
            className="form-control"
          >
            <option value="FRONTEND">FRONTEND</option>
            <option value="BACKEND">BACKEND</option>
            <option value="API">API</option>
            <option value="BD">BD</option>
          </select>
        </div>

        <div className="form-group">
          <label>Team Members:</label>
          <div className="members-checkbox-container">
            {users.map((email, index) => (
              <div key={`member-${index}`} className="member-checkbox">
                <input
                  type="checkbox"
                  id={`member-${index}`}
                  checked={projectData.members.includes(email)}
                  onChange={() => handleMemberChange(email)}
                />
                <label htmlFor={`member-${index}`}>
                  {email}
                </label>
              </div>
            ))}
          </div>
        </div>

        <div className="form-group">
          <label>Team Testers:</label>
          <div className="members-checkbox-container">
            {users.map((email, index) => (
              <div key={`tester-${index}`} className="member-checkbox">
                <input
                  type="checkbox"
                  id={`tester-${index}`}
                  checked={projectData.testers.includes(email)}
                  onChange={() => handleTesterChange(email)}
                />
                <label htmlFor={`tester-${index}`}>
                  {email}
                </label>
              </div>
            ))}
          </div>
        </div>

        <button type="submit" className="submit-button">Register Project</button>
      </form>
    </div>
  );
};

export default ProjectForm;