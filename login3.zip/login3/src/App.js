import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import LoginSignup from './Components/LoginSignup/LoginSignup';
import SignUp from './Components/LoginSignup/SignUp';
import Dashboard from './Components/Dashboard';
import ProjectForm from './Components/LoginSignup/ProjectForm';
import About from './Components/About';
import Layout from './Components/Layout';
import Features from './Components/Features';

const App = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false); // Stare pentru logare

  useEffect(() => {
    const loggedIn = localStorage.getItem('isLoggedIn') === 'true'; // Verifică valoarea stocată în localStorage
    setIsLoggedIn(loggedIn);
  }, []); // Se execută doar la montarea componentelor

  const handleLogin = () => {
    setIsLoggedIn(true); // Setează utilizatorul ca fiind logat
    localStorage.setItem('isLoggedIn', 'true'); // Salvează în localStorage
  };

  const handleLogout = () => {
    setIsLoggedIn(false); // Setează utilizatorul ca fiind delogat
    localStorage.removeItem('isLoggedIn'); // Șterge valoarea din localStorage
  };



  return (
    <Router>
      <Routes>
        {/* Rutele pentru Home și SignUp */}
        <Route path="/" element={<LoginSignup onLogin={handleLogin} />} />
        <Route path="/signup" element={<SignUp />} />

        {/* Rutele pentru Dashboard - protejate de autentificare */}
        <Route
          path="/dashboard"
          element={isLoggedIn ? <Dashboard onLogout={handleLogout} /> : <LoginSignup onLogin={handleLogin} />}
        />

        {/* Rutele pentru pagini care includ Layout (Navbar) */}
        <Route path="/" element={<Layout />}>
          <Route path="about" element={<About />} />
          <Route path="features" element={<Features />} />
        </Route>
    </Routes>
    </Router>
    // <ProjectForm/>
    
  );
};

export default App;
